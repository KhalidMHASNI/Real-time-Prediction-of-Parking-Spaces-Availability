# ParkingSpace > 2023-12-22 6:37pm
https://universe.roboflow.com/mi3ad/parkingspace-neflg

Provided by a Roboflow user
License: CC BY 4.0

